package com.custom.holomusic;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    private Button btnPlay, btnPrev, btnNext, btnOpenPlaylists;
    private TextView tvSongTitle, tvArtist;
    private SeekBar seekBar;
    private ImageView ivAlbumArt;
    private boolean isPlaying = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Music H");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        btnPlay = findViewById(R.id.btnPlay);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnOpenPlaylists = findViewById(R.id.btnOpenPlaylists);
        tvSongTitle = findViewById(R.id.tvSongTitle);
        tvArtist = findViewById(R.id.tvArtist);
        seekBar = findViewById(R.id.seekBar);
        ivAlbumArt = findViewById(R.id.ivAlbumArt);

        seekBar.setProgress(20);

        btnPlay.setOnClickListener(v -> {
            isPlaying = !isPlaying;
            if (isPlaying) {
                btnPlay.setText("PAUSE");
                Toast.makeText(MainActivity.this, "Resuming Playback", Toast.LENGTH_SHORT).show();
            } else {
                btnPlay.setText("PLAY");
                Toast.makeText(MainActivity.this, "Playback Paused", Toast.LENGTH_SHORT).show();
            }
        });

        btnPrev.setOnClickListener(v -> Toast.makeText(MainActivity.this, "Previous track", Toast.LENGTH_SHORT).show());
        btnNext.setOnClickListener(v -> Toast.makeText(MainActivity.this, "Next track", Toast.LENGTH_SHORT).show());

        btnOpenPlaylists.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, PlaylistActivity.class);
            startActivity(intent);
        });
    }
}
